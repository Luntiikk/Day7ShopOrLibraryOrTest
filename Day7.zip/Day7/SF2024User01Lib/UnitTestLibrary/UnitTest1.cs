﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SF2024User01Lib;


namespace UnitTestLibrary
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AvailablePeriods_NoConsultationsReturnsWholeWorkingDay()//нет консультаций весь день
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result =Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-17:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_SingleConsultationAtBeginningOfDay_ReturnsCorrectSlots()//одна консультация вначале дня
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0) };
            int[] durations = { 30 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:30-17:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsCoverWholeDay_ReturnsNoFreeSlots()//консультации целый день
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(11, 0, 0) };
            int[] durations = { 480, 360 }; // Covering the whole working day
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(0, result.Length);
        }
        [TestMethod]
        public void AvailablePeriods_MultipleConsultations_ReturnsCorrectSlots()//многократные консультации
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(13, 0, 0) };
            int[] durations = { 60, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("10:00-13:00", result[0]);
            Assert.AreEqual("13:45-17:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_SingleConsultationAtEndOfDay_ReturnsCorrectSlots()//одна консультация в конце дня
        {
            TimeSpan[] startTimes = { new TimeSpan(16, 30, 0) };
            int[] durations = { 30 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-16:30", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationEndsExactlyAtEndOfWorkingDay_ReturnsCorrectSlots()//консультация, заканчивающаяся в конце рабочего дня
        {
            TimeSpan[] startTimes = { new TimeSpan(15, 30, 0) };
            int[] durations = { 150 }; 
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-15:30", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_NoConsultationsAndShorterWorkingDay_ReturnsWholeAdjustedWorkingDayAsFreeSlot()//нет консультаций, сокращенный рабочий день
        {
            TimeSpan[] startTimes = { };
            int[] durations = { };
            TimeSpan beginWorkingTime = new TimeSpan(10, 0, 0); 
            TimeSpan endWorkingTime = new TimeSpan(16, 0, 0); 
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("10:00-16:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsOverlap_ReturnsCorrectSlots()//Консультации дублируются
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(9, 30, 0), new TimeSpan(10, 0, 0) };
            int[] durations = { 60, 30, 45 }; 
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("08:00-09:00", result[0]);
            Assert.AreEqual("10:45-12:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_ConsultationsDoNotOverlap_ReturnsCorrectSlots()//консультации не дублируются
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(10, 0, 0), new TimeSpan(13, 0, 0) };
            int[] durations = { 60, 30, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(2, result.Length);
            Assert.AreEqual("08:00-09:00", result[0]);
            Assert.AreEqual("10:30-13:00", result[1]);
        }
        [TestMethod]
        public void AvailablePeriods_NoConsultations_ReturnsFullWorkingTime()//нет консультаций
        {
            TimeSpan[] startTimes = { };
            int[] durations = { };
            TimeSpan beginWorkingTime = new TimeSpan(8, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("08:00-17:00", result[0]);
        }
        [TestMethod]
        public void AvailablePeriods_NoAvailableSlots_ReturnsEmptyArray()//все время занято
        {
            TimeSpan[] startTimes = { new TimeSpan(9, 0, 0), new TimeSpan(10, 0, 0), new TimeSpan(11, 0, 0) };
            int[] durations = { 60, 60, 45 };
            TimeSpan beginWorkingTime = new TimeSpan(9, 0, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 0, 0);
            int consultationTime = 30;

            string[] result = Calculations.GetFreeTimeSlots(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            Assert.AreEqual(0, result.Length);
        }
    }
}
