﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF2024User01Lib
{
    public class Calculations
    {
        public static string[] GetFreeTimeSlots(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {
            List<string> freeTimeSlots = new List<string>();

            TimeSpan currentTime = beginWorkingTime;
            for (int i = 0; i < startTimes.Length; i++)
            {
                TimeSpan busyEndTime = startTimes[i] + TimeSpan.FromMinutes(durations[i]);
                if (currentTime + TimeSpan.FromMinutes(consultationTime) <= startTimes[i])
                {
                    freeTimeSlots.Add($"{currentTime:hh\\:mm}-{startTimes[i]:hh\\:mm}");
                }
                currentTime = busyEndTime;
            }

            if (currentTime + TimeSpan.FromMinutes(consultationTime) <= endWorkingTime)
            {
                freeTimeSlots.Add($"{currentTime:hh\\:mm}-{endWorkingTime:hh\\:mm}");
            }

            return freeTimeSlots.ToArray();
        }
    }
}
